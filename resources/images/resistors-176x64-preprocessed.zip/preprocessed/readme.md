Filters
# remove shadow
# gaussian blur (1)